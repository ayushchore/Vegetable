
function blue1(){
    document.getElementById("i5").style.display="block"
}
function red1(){
    document.getElementById("i5").style.display="none"
}
function blue2(){
    document.getElementById("i6").style.display="block"
}
function red2(){
    document.getElementById("i6").style.display="none"
}
function blue3(){
    document.getElementById("i7").style.display="block"
}
function red3(){
    document.getElementById("i7").style.display="none"
}
function blue4(){
    document.getElementById("i8").style.display="block"
}
function red4(){
    document.getElementById("i8").style.display="none"
}


